## Assignment 3, Page 7: Segment Text

