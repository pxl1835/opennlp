## Assignment 3, Page 3: Apply Regex Symbols

