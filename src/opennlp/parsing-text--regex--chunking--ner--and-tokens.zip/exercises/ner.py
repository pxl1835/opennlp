## Assignment 3, Page 6: Use NER

