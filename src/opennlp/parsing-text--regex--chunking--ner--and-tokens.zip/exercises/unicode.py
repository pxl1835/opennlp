## Assignment 3, Page 4: Utilize Unicode

