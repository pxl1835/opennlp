## Assignment 3, Page 5: Chunk & Chink Text

