## Assignment 3, Page 2: Use Regex

## Import Processes for Applying Regex
import re
from re import finditer

## Use re.search: Use re.search() to Search for the Pattern in the String
adv_sentence = "After last summer's adventures, we're up to any task!"

pattern = r'...adventure'
match = re.search(pattern, adv_sentence)
if match != None: print("\nThere is a match. The string 'adventure' starts on the ", match.start(), 'th letter.')
else: print("\nThe computer wasn't able to find a match.")

## Use re.search, Variation: Use re.search() to Search for Multiple Patterns in the String
pattern2 = ['adventures', 'adventure', 'dog']
for element in pattern2:
  if re.search(element, adv_sentence): print('\nMatch! The computer found the pattern "%s" in the sentence: "%s"' % (element, adv_sentence), end = '\n')
  else: print('\nNo Match! The computer was not able to find the pattern "%s" in the sentence: "%s"' % (element, adv_sentence), end = '\n')

## Use re.findall: Use re.findall() to Find All Occurrences of the Patterns in the Strings
art_sentences = ['There is no greater joy for an artist than to know their work is in the hands of someone who truly understands it.', 'These guys have state of the art equipment.']

pattern3 = ['art', 'artist', 'dog']
for art_sentence in art_sentences:
  for each_pattern3 in pattern3:
    if re.findall(each_pattern3, art_sentence): print('\nMatch! The pattern "%s" is in the sentence: "%s"' % (each_pattern3, art_sentence), end = '\n')
    else: print('\nNo Match! The pattern "%s" is not in the sentence: "%s"' % (each_pattern3, art_sentence), end = '\n')

## Use re.findall, Variation: 
for art_sentence in art_sentences:
  for each_pattern3 in pattern3:
    if re.findall(each_pattern3, art_sentence):
      for each_pattern_found in finditer(each_pattern3, art_sentence):
        print('\nMatch! Location: ', each_pattern_found.span(), '. The pattern "%s" is in the sentence: "%s"' % (each_pattern3, art_sentence), end = '\n')
    else: print('\nNo Match! The pattern "%s" is not in the sentence: "%s"' % (each_pattern3, art_sentence), end = '\n')