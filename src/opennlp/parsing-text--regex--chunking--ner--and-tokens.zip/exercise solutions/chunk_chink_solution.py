## Assignment 3, Page 5: Chunk & Chink Text

## Import Processes for Chinking and Chunking
from nltk.tokenize import word_tokenize
from nltk import pos_tag, RegexpParser

## Chunk Text: Chunk Noun Phrases from Text
head_quote = "It's strange how a word, a phrase, a sentence, can feel like a blow to the head."
head_quote_words = word_tokenize(head_quote)
head_quote_tags = pos_tag(head_quote_words)

chunk_grammar_NP = r"NP: {<DT>?<JJ>*<NN>}"
chunk_parser_NP = RegexpParser(chunk_grammar_NP)
head_quote_chunked = chunk_parser_NP.parse(head_quote_tags)
print("\nChunked Noun Phrases in 'head_quote': \n", head_quote_chunked)

## Chunk Text, Variation: Chunk Verb Phrases from Text
painting = "I finally told my mother my passion, which is that I love painting."
painting_words = word_tokenize(painting)
painting_tags = pos_tag(painting_words)

chunk_grammar_VP = "VP: {<VPD>*<VBG>}"
chunk_parser_VP = RegexpParser(chunk_grammar_VP)

print("\nChunked Verb Phrases in 'painting': \n", chunk_parser_VP.parse(painting_tags))

## Chink Text: Chunk All Words, Chink all Adjectives from Text
medal_quote = "These boys collected the bronze medal for third team place and were only ten points away from earning a gold medal."
medal_quote_tokens = word_tokenize(medal_quote)
medal_quote_tags = pos_tag(medal_quote_tokens)

chunk_grammar_noJJ = """NoAdjChunk: {<.*>+}
  }<JJ>{"""
chunk_parser_noJJ = RegexpParser(chunk_grammar_noJJ)
medal_quote_chunked = chunk_parser_noJJ.parse(medal_quote_tags)
print("\nChunked 'medal_quote' without Adjectives: \n", medal_quote_chunked)

## Chink Text, Variation: Chunk All Noun Phrases, Chink All Verbs from Text
chunk_grammar_NP_noVB = """
  NP: {<DT><NN.*><.*>*<NN.*>}
  }<VB.*>{"""

chunk_parser_NP_noVB = RegexpParser(chunk_grammar_NP_noVB)
head_quote_chunked2 = chunk_parser_NP_noVB.parse(head_quote_tags)
print("\nChunked Noun Phrases in 'head_quote' without Verbs: \n", head_quote_chunked2)