## Assignment 3, Page 7: Segment Text

## Import Processes for Using NLTK's Regexp Tokenizer
from nltk.tokenize import RegexpTokenizer

## Use RegexpTokenizer: Use NLTK's Regexp Tokenizer to Tokenize by White Space
white_space_pattern = RegexpTokenizer('\s+', gaps = True)
codio = 'Codio is the best computer science learning tool.'
codio_tokenized = white_space_pattern.tokenize(codio)
print("\nOriginal Output of 'codio': ", codio)
print("\nRegexp Tokenizer Tokenized Output of 'codio': ", codio_tokenized)

## Use RegexpTokenizer, Variation Solution: Use RegexpTokenizer to Tokenize by Uppercase Alphabet
uppercase_pattern = RegexpTokenizer('[A-Z]+', gaps = False)
magic = 'My teacher, Ms. Sanford, said there is always magic in the air if you believe in it.'
magic_tokenized = uppercase_pattern.tokenize(magic)
print("\nRegexp Tokenizer by Uppercase Tokenized Output of 'magic': ", magic_tokenized)

## Manually Segment Text: Create a Segmentation Function Determined by Segment Bit Value
def segment_text(text, segment):
  words = []
  last = 0
  for element in range(len(segment)):
    if segment[element] == '1':
      words.append(text[last: element + 1])
      last = element + 1
  words.append(text[last:])
  return words

happy_text = 'Happydaysarealwayshere.'
seg_happy_text = '00001000100100000100010'
print("\nOriginal Output of 'happy_text': ", happy_text)
print("\nManually Segmented Output of 'happy_text': ", segment_text(happy_text, seg_happy_text))

## Manually Segment Text, Variation Solution: Manually Segment 'hotel_ad' Using the User-Defined Function called 'segment'
hotel_ad = 'Theroomyouneedattheresortyoutrustwithwell-appointedroomsandfriendly,personalizedservice.'
seg_hotel_ad = '0010001001000101001000001001000010001000000000000010000100100000001100000000000100000010'
print("\nManually Segmented Output of 'hotel_ad': ", segment_text(hotel_ad, seg_hotel_ad))

