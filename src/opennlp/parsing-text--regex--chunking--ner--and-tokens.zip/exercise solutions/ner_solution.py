## Assignment 3, Page 6: Use NER

## Import Processes for Using NER
import nltk
from nltk.tokenize import word_tokenize
from nltk import pos_tag, ne_chunk

## Use ne_chunk: Find the Named Entities in the Text
coffee = "Angela Merkel grabbed the cup of coffee and took a sip as she stepped around the corner of Starbucks."
coffee_tokens = word_tokenize(coffee)
coffee_tags = pos_tag(coffee_tokens)

coffee_NEs = ne_chunk(coffee_tags)
print("\nName Entities in 'coffee': ", coffee_NEs)

## Use ne_chunk, Variation Solution: Create a Function to Find the Named Entities in the Text
def find_NEs(text):
  tokens = word_tokenize(text)
  tags = pos_tag(tokens)
  return(ne_chunk(tags))

print("\nName Entities in 'coffee' using User-Defined Function: ", find_NEs(coffee))

## Use hasattr: Use hasattr() to Return the Output
def find_NEs_pretty(text):
  tokens = word_tokenize(text)
  tags = pos_tag(tokens)
  NEs = ne_chunk(tags, binary=True)
  return set(
    " ".join(word[0] for word in chunked_word)
    for chunked_word in NEs
    if hasattr(chunked_word, "label") and chunked_word.label() == "NE")

print("\nName Entities in 'space' using hasattr(): ", find_NEs_pretty(space))

## Use hasattr, Variation: What happens when Binary is set to 'False'?
def find_NEs_pretty2(text):
  tokens = word_tokenize(text)
  tags = pos_tag(tokens)
  NEs = ne_chunk(tags, binary=False)
  return set(
    " ".join(word[0] for word in chunked_word)
    for chunked_word in NEs
    if hasattr(chunked_word, "label") and chunked_word.label() == "NE")

print("\nName Entities in 'space' using hasattr(): ", find_NEs_pretty2(space))
