## Assignment 3, Page 3: Apply Regex Symbols

## Import Processes for Regex
import re

## Use Basic Meta Characters, Operators, & Quantifiers: Find All Matches
king = 'After the death of the king, everyone wanted to be a king.'

pattern1 = r'\sking'
match1 = re.findall(pattern1, king)

if match1: print('\nMatch! The pattern "%s" is in the sentence: "%s"' % (pattern1, king), end = '\n')
else: print('\nNo Match! The pattern "%s" is not in the sentence: "%s"' % (pattern1, king), end = '\n')

pattern2 = r'k..g$'
match2 = re.findall(pattern2, king)

if match2: print('\nMatch! The pattern "%s" is in the sentence: "%s"' % (pattern2, king), end = '\n')
else: print('\nNo Match! The pattern "%s" is not in the sentence: "%s"' % (pattern2, king), end = '\n')

dessert = 'The most awesome meal of the day is dessert because it can be whatever you want.'
pattern3 = r'de.*ert'
match3 = re.findall(pattern3, dessert)

if match3: print('\nMatch! The pattern "%s" is in the sentence: "%s"' % (pattern3, dessert), end = '\n')
else: print('\nNo Match! The pattern "%s" is not in the sentence: "%s"' % (pattern3, dessert), end = '\n')

## Use Square Brackets & Parentheses: Find All Matches
pattern4 = r'[123]'
pattern5 = r'[1-3]'
pattern6 = r'[^1-3]'

numbers = '315-897-4873'

patterns456 = [pattern4, pattern5, pattern6]
for pattern in patterns456:
  if re.findall(pattern, numbers): print('\nMatch! At least one of the numbers in "%s" is in the string: "%s"' % (pattern, numbers), end = '\n')
  else: print('\nNo Match! None of the numbers in "%s" are in the string: "%s"' % (pattern, numbers), end = '\n')

pattern7 = r'(\d+-\d+-\d+)'
pattern8 = r'(\d+)-\d+-\d+'

patterns78 = [pattern7, pattern8]
for pattern in patterns78:
  if re.findall(pattern, numbers):
    print('\nMatch! At least one of the numbers in "%s" is in the string: "%s"' % (pattern, numbers), end = '\n')
    print('Pattern found:', re.findall(pattern, numbers))
  else: print('\nNo Match! None of the numbers in "%s" are in the string: "%s"' % (pattern, numbers), end = '\n')

## Exercise 2, Variation: 
pattern9 = r'[1-3]\d{3}'
pattern10 = r'(1|2|3)\d{3}'

numbers2 = '14590813302'

patterns910 = [pattern9, pattern10]
for pattern in patterns910:
  if re.findall(pattern, numbers2):
    print('\nMatch! At least one of the numbers in "%s" is in the string: "%s"' % (pattern, numbers2), end = '\n')
    print('Pattern found:', re.findall(pattern, numbers2))
  else: print('\nNo Match! None of the numbers in "%s" are in the string: "%s"' % (pattern, numbers2), end = '\n')
