## Assignment 3, Page 4: Utilize Unicode

## Use Latin-2 Encoding: Use Latin-2 Encoding
path_1 = '.guides/exercises/unicode_text.txt'

text_latin2 = open(path_1, encoding = 'latin2')
print("\nPlain Text from path_1 using Latin-2 encoding:")
for line in text_latin2:
  line = line.strip()
  print(line)

## Use Latin-2 Encoding, Variation: Display Latin-2 Code Points in Output
text_latin2 = open(path_1, encoding = 'latin2')
print("\nPlain Text from path_1 using Latin-2 encoding with code points:")
for line in text_latin2:
  line = line.strip()
  print(line.encode('unicode_escape'))

print("\nThe ASCII value of 'e':", ord('e'))
import string
print("\nASCII Letters:", string.ascii_letters)
print("ASCII Printable Characters:", string.printable)

print("The Unicode Value of 'ö':", ord('ö')) ##value is equal to: 246
hex_of_246 = hex(246)
print('Hexidecimal Value of 246:', hex_of_246) ##value is equal to: 0xf6
escape_sequence_246 = '\xf6'
print("Plain Text of Escape Sequence '\xf6':", escape_sequence_246) ##value is equal to: ö

## Use UTF-8 Encoding: Use UTF-8 Encoding
text_utf8 = open(path_1, encoding = 'utf8')
print("\nPlain Text from path_1 using UTF-8 encoding:")
for line in text_utf8:
  line = line.strip()
  print(line)

byte_sequence = escape_sequence_246.encode('utf8') ## value is equal to: b'\xc3\xb6'
print("\nUTF-8 Byte Sequence Inside ö:", byte_sequence)

## Use UTF-8 Encoding, Variation: Use Unicode with Regex
import re

lines_in_text = open(path_1, encoding = 'latin2').readlines()
line_1 = lines_in_text[0]
line_1 = line_1.encode('unicode_escape')
print("\nLine 1 of the Text:", str(line_1))

unicode_in_line_1 = re.search(r"\\u015b\w*", str(line_1))
print("Words with Unicode 'u015b':", unicode_in_line_1.group())